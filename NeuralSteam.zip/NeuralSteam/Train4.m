function [ output_args ] = Train4( input_args )
%TRAIN4 Summary of this function goes here
%   Detailed explanation goes here


end

