function [ output_args ] = Train5( input_args )
%TRAIN5 Summary of this function goes here
%   Detailed explanation goes here


end

