% %script imports saturated steam table values from Steam_Tables.xlsx sheet
% P in bar 
% T in C
% v in m3/kg 
% u in KJ/kg
% h in KJ/kg
% s in KJ/(kg K)
 
% uevap = xlsread('Steam_Tables.xlsx','Saturated','H5:H405'); %evap is diff
% hevap = xlsread('Steam_Tables.xlsx','Saturated','K5:K405'); %b/w liq & vap
% sevap = xlsread('Steam_Tables.xlsx','Saturated','N5:N405');

%import steam table values
filename = 'Steam_Tables.xlsx';

satval = xlsread(filename,'Saturated','C5:L405');
superval = xlsread(filename,'Superheated','C5:BP405');
subval = xlsread(filename, 'Subcooled','E5:K864');
superT = xlsread(filename,'Superheated','A4:A19');
%define steam table values

%========================
%*****************************TRAIN DATA**********************************
%data will be trained in 6 sections, titled ANN#  
%ANN stands for Artificial Neural Network

%section 1: subcool,     p=0.01-220 bar
%section 2: subcool,     p=220-500 bar
%section 3: saturated,   p=0.01-220.63
%section 4: superheated, p=0.01-1 bar
%section 5: superheated, p=1-94 bar
%section 6:= superheated, p=94-220.63 bar

%Each section will call a script, which will train passed parameters, which
%will then return weighted values. 

%Train Subcooled
%Section 1, p=0.01-220 bar
[W1,emean1,yk,T1,emin1,emax1] =Train1H(subval);
% W1tab = table(W1);
% writetable(W1tab,filename,'Sheet',4,'D4');
%^didn't work


% %Section 2, p=220-500 bar
 [W2,emean2,yk,T2,emin2,emax2] =Train2(subval);
% 
% 
% %Train Saturated
% %Section 3, p=0.01-220.63
% [W3,emean3] =Train2(satval);
% 
% 
% %Train Superheated
% %Section 4, p=0.01-1 bar
% [W4,emean4] =Train4(superval);
% 
% 
% 
% %Section 5, p=1-94 bar
% [W5,emean5] =Train5(superval);
% 
% 
% %Section 6, p=94-220.63 bar
% [W6,emean6] =Train6(superval);
% 
% 
% 
