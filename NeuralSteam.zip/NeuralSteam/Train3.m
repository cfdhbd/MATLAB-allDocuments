function [Psat] = Train3(satval)
%TRAIN3 Summary of this function goes here
%   Detailed explanation goes here

Psat = satval(:,1); Tsat=satval(:,2); 
vLsat = satval(:,3); vVsat=satval(:,4);
uLsat = satval(:,5);  uevap = satval(:,6);  uVsat=satval(:,7);
hLsat = satval(:,8);  hevap = satval(:,9);  hVsat = satval(:,10);
sLsat = satval(:,11); sevap = satval(:,12); sVsat = satval(:,13);

error = 

end

