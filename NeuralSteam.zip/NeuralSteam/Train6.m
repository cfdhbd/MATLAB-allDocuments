function [ output_args ] = Train6( input_args )
%TRAIN6 Summary of this function goes here
%   Detailed explanation goes here


end

